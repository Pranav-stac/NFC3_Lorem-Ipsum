from django.apps import AppConfig


class TsecapiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "TsecAPI"
